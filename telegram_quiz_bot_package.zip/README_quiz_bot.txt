# Telegram English Quiz Bot

## 1. Create your bot
1. Telegram’da `@BotFather` ni oching.
2. `/newbot` yuboring va bot nomi/username tanlang.
3. BotFather bergan tokenni o‘zingizda saqlang. Tokenni chatga yubormang.

## 2. Run on a computer
Python 3.10 yoki yangiroq versiya kerak.

Terminal/Command Prompt’da bot fayllari turgan papkaga kiring va:

```bash
python -m pip install -r requirements.txt
```

Tokenni environment variable sifatida o‘rnating:

Windows PowerShell:
```powershell
$env:BOT_TOKEN="BOTFATHER_BERGAN_TOKEN"
python telegram_quiz_bot.py
```

macOS/Linux:
```bash
export BOT_TOKEN="BOTFATHER_BERGAN_TOKEN"
python telegram_quiz_bot.py
```

Telegram’da botingizni ochib `/start`, so‘ng `/quiz` yuboring.
`/quiz 20` — 20 ta savol; `/score` — joriy natija; `/stop` — to‘xtatish.

## Fayllar
- `telegram_quiz_bot.py` — bot kodi.
- `quiz_questions.json` — hozircha hujjatning boshidagi 22 ta savol, javoblari tekshirilgan.
- `requirements.txt` — kerakli kutubxona.

Eslatma: bot ishlashi uchun kompyuter/serverda skript ishga tushib turishi kerak. Hozirgi savollar banki 5000 ta savolning hammasi emas; qolgan savollarni keyingi qismlarda qo‘shish mumkin.
