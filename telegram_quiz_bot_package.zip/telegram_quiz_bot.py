import json
import os
import random
import logging
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes
)

logging.basicConfig(level=logging.INFO)
TOKEN = os.getenv("BOT_TOKEN")
BANK_FILE = Path(__file__).with_name("quiz_questions.json")

with BANK_FILE.open(encoding="utf-8") as f:
    QUESTIONS = json.load(f)

# Each user's progress is kept in memory while the bot is running.
sessions = {}

def question_keyboard(q_index, q):
    rows = []
    for option_index, option in enumerate(q["options"]):
        rows.append([InlineKeyboardButton(
            option, callback_data=f"ans:{q_index}:{option_index}"
        )])
    return InlineKeyboardMarkup(rows)

async def send_question(update, context, user_id):
    session = sessions.get(user_id)
    if not session:
        return
    if session["position"] >= len(session["order"]):
        correct = session["correct"]
        total = len(session["order"])
        percent = round(correct * 100 / total) if total else 0
        await context.bot.send_message(
            chat_id=user_id,
            text=f"🏁 Test tugadi!\nNatija: {correct}/{total} ({percent}%).\n"
                 f"Yangi test uchun /quiz buyrug‘ini yuboring."
        )
        sessions.pop(user_id, None)
        return

    q_index = session["order"][session["position"]]
    q = QUESTIONS[q_index]
    session["current"] = q_index
    await context.bot.send_message(
        chat_id=user_id,
        text=f"❓ {session['position'] + 1}/{len(session['order'])}\n\n{q['question']}",
        reply_markup=question_keyboard(q_index, q)
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Salom! Ingliz tili quiz botiga xush kelibsiz.\n"
        "/quiz — testni boshlash\n/score — joriy natija\n/stop — testni to‘xtatish"
    )

async def quiz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    count = min(len(QUESTIONS), 10)
    if context.args:
        try:
            count = max(1, min(len(QUESTIONS), int(context.args[0])))
        except ValueError:
            await update.message.reply_text("Savollar sonini raqam bilan yozing: /quiz 10")
            return
    order = list(range(len(QUESTIONS)))
    random.shuffle(order)
    order = order[:count]
    sessions[user_id] = {"order": order, "position": 0, "correct": 0, "answered": False}
    await send_question(update, context, user_id)

async def answer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    try:
        _, q_index, option_index = query.data.split(":")
        q_index, option_index = int(q_index), int(option_index)
    except (ValueError, AttributeError):
        return

    user_id = query.from_user.id
    session = sessions.get(user_id)
    if not session or session.get("current") != q_index or session.get("answered"):
        await query.answer("Bu savolga javob berilgan yoki test tugagan.", show_alert=True)
        return

    q = QUESTIONS[q_index]
    correct_index = q["answer"]
    session["answered"] = True
    if option_index == correct_index:
        session["correct"] += 1
        feedback = "✅ To‘g‘ri!"
    else:
        feedback = f"❌ Noto‘g‘ri.\nTo‘g‘ri javob: {q['options'][correct_index]}"

    await query.edit_message_text(
        text=f"{q['question']}\n\nSizning javobingiz: {q['options'][option_index]}\n\n{feedback}",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("Keyingi ➡️", callback_data="next")
        ]])
    )

async def next_question(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    session = sessions.get(user_id)
    if not session or not session.get("answered"):
        return
    session["position"] += 1
    session["answered"] = False
    await query.edit_message_reply_markup(reply_markup=None)
    await send_question(update, context, user_id)

async def score(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = sessions.get(update.effective_user.id)
    if not session:
        await update.message.reply_text("Hozir faol test yo‘q. /quiz bilan boshlang.")
        return
    await update.message.reply_text(
        f"Joriy natija: {session['correct']} ta to‘g‘ri.\n"
        f"Javob berilgan: {session['position']} ta."
    )

async def stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    sessions.pop(update.effective_user.id, None)
    await update.message.reply_text("Test to‘xtatildi. /quiz bilan qayta boshlang.")

def main():
    if not TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable is missing.")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("quiz", quiz))
    app.add_handler(CommandHandler("score", score))
    app.add_handler(CommandHandler("stop", stop))
    app.add_handler(CallbackQueryHandler(next_question, pattern="^next$"))
    app.add_handler(CallbackQueryHandler(answer, pattern="^ans:"))
    app.run_polling()

if __name__ == "__main__":
    main()
